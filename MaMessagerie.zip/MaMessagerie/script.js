function sendMessage() {
    var message = $('#message-input').val();

    if (message.trim() !== '') {
        $.ajax({
            url: 'php/messages.php',
            method: 'POST',
            data: { message: message },
            success: function(response) {
                $('#message-input').val('');
                fetchMessages();
            }
        });
    }
}

function fetchMessages() {
    $.ajax({
        url: 'php/messages.php',
        method: 'GET',
        success: function(response) {
            $('#messages-container').html(response);
        }
    });
}

$(document).ready(function() {
    fetchMessages();
    setInterval(fetchMessages, 3000); // Actualisez les messages toutes les 3 secondes (ajustez selon vos besoins)
});
