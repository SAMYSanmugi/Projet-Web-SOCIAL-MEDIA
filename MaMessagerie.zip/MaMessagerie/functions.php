<?php
include('config.php');

function getMessages() {
    global $conn;
    $sql = "SELECT * FROM messages ORDER BY timestamp DESC";
    $result = $conn->query($sql);
    
    $messages = array();
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
    }

    return $messages;
}

function saveMessage($message) {
    global $conn;
    $sql = "INSERT INTO messages (content) VALUES ('$message')";
    $conn->query($sql);
}
?>
