<?php
include('functions.php');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $messages = getMessages();

    foreach ($messages as $message) {
        echo '<p>' . $message['content'] . '</p>';
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $message = $data['message'];
    
    saveMessage($message);
}
?>
