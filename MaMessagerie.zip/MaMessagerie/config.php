<?php
$servername = "localhost";
$username = "votre_nom_utilisateur_mysql";
$password = "votre_mot_de_passe_mysql";
$dbname = "votre_nom_de_base_de_donnees";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("La connexion à la base de données a échoué : " . $conn->connect_error);
}
?>
